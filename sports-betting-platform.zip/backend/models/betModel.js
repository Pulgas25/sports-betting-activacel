const mongoose = require('mongoose');

const betSchema = new mongoose.Schema({
  user: String,
  amount: Number,
  odds: Number,
  status: { type: String, default: 'pending' },
});

module.exports = mongoose.model('Bet', betSchema);
