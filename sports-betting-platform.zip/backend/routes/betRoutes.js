const express = require('express');
const Bet = require('../models/betModel');
const router = express.Router();

router.post('/placeBet', (req, res) => {
  const { user, amount, odds } = req.body;
  const newBet = new Bet({ user, amount, odds });
  newBet.save().then(bet => res.status(201).json(bet))
    .catch(err => res.status(400).send(err));
});

module.exports = { betRoutes: router };
