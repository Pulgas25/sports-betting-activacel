const express = require('express');
const User = require('../models/userModel');
const jwt = require('jsonwebtoken');
const router = express.Router();

router.post('/register', (req, res) => {
  const { username, password } = req.body;
  const newUser = new User({ username, password });
  newUser.save().then(user => res.status(201).json(user))
    .catch(err => res.status(400).send(err));
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  User.findOne({ username }).then(user => {
    if (user && user.password === password) {
      const token = jwt.sign({ id: user._id, role: 'user' }, process.env.JWT_SECRET_KEY);
      res.json({ token });
    } else {
      res.status(401).send('Invalid credentials');
    }
  });
});

module.exports = { userRoutes: router };
