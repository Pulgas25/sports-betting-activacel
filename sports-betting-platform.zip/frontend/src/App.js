import React from 'react';
import axios from 'axios';

function App() {
  const placeBet = async () => {
    const betData = { user: 'user1', amount: 50, odds: 2.0 };

    try {
      const response = await axios.post('http://localhost:3000/bets/placeBet', betData);
      console.log('Bet placed:', response.data);
    } catch (error) {
      console.error('Error placing bet:', error);
    }
  };

  return (
    <div className="App">
      <h1>Sports Betting Platform</h1>
      <button onClick={placeBet}>Place Bet</button>
    </div>
  );
}

export default App;
